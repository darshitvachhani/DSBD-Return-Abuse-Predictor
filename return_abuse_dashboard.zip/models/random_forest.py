import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import plot_tree
from sklearn.metrics import roc_curve, roc_auc_score
from models.utils import fig_to_base64, calc_metrics

def run_random_forest(data_bundle, n_trees=100, depth=8, rf_thresh=0.50, seed=42):
    X_tr = data_bundle['X_train']
    X_te = data_bundle['X_test']
    y_tr = data_bundle['y_train']
    y_te = data_bundle['y_test']

    rf = RandomForestClassifier(n_estimators=int(n_trees), max_depth=int(depth), min_samples_leaf=10, random_state=seed, n_jobs=-1)
    rf.fit(X_tr, y_tr)
    y_prob = rf.predict_proba(X_te)[:, 1]
    y_pred = (y_prob >= rf_thresh).astype(int)
    metrics = calc_metrics(y_te, y_pred, y_prob)

    fig_t, ax = plt.subplots(figsize=(10, 4.4))
    plot_tree(rf.estimators_[0], feature_names=X_tr.columns.tolist(), class_names=['Legit', 'Abuse'],
              max_depth=3, filled=True, rounded=True, precision=2, fontsize=8, impurity=False, proportion=True, ax=ax)
    tree_b64 = fig_to_base64(fig_t)

    fig_i, ax = plt.subplots(figsize=(6, 3.2))
    pd.Series(rf.feature_importances_, index=X_tr.columns).sort_values().tail(8).plot(kind='barh', color='#2ca02c', ax=ax)
    ax.set_title("Random Forest: Top 8 Predictors", fontsize=10, fontweight='bold')
    imp_b64 = fig_to_base64(fig_i)

    fig_r, ax = plt.subplots(figsize=(5.5, 3.2))
    fpr, tpr, _ = roc_curve(y_te, y_prob)
    ax.plot(fpr, tpr, color='#2ca02c', lw=2, label=f"AUC = {roc_auc_score(y_te, y_prob):.4f}")
    ax.plot([0, 1], [0, 1], 'k--', lw=1)
    ax.legend(loc='lower right')
    roc_b64 = fig_to_base64(fig_r)

    return {
        'model': rf, 'y_prob': y_prob, 'metrics': metrics,
        'plots': {'rf_tree': tree_b64, 'rf_imp': imp_b64, 'roc_rf': roc_b64}
    }
