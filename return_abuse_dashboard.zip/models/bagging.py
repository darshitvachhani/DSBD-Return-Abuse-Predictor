import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import BaggingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import roc_curve, roc_auc_score
from models.utils import fig_to_base64, calc_metrics

def run_bagging(data_bundle, n_trees=60, depth=8, bag_thresh=0.50, seed=42):
    X_tr = data_bundle['X_train']
    X_te = data_bundle['X_test']
    y_tr = data_bundle['y_train']
    y_te = data_bundle['y_test']

    bag = BaggingClassifier(
        estimator=DecisionTreeClassifier(max_depth=int(depth), min_samples_leaf=5, random_state=seed),
        n_estimators=int(n_trees), random_state=seed, n_jobs=-1
    )
    bag.fit(X_tr, y_tr)
    y_prob = bag.predict_proba(X_te)[:, 1]
    y_pred = (y_prob >= bag_thresh).astype(int)
    metrics = calc_metrics(y_te, y_pred, y_prob)

    bag_imp = np.mean([tree.feature_importances_ for tree in bag.estimators_], axis=0)
    fig_i, ax = plt.subplots(figsize=(6, 3.2))
    pd.Series(bag_imp, index=X_tr.columns).sort_values().tail(8).plot(kind='barh', color='#9467bd', ax=ax)
    ax.set_title("Bagging: Mean Feature Importance", fontsize=10, fontweight='bold')
    imp_b64 = fig_to_base64(fig_i)

    fig_r, ax = plt.subplots(figsize=(5.5, 3.2))
    fpr, tpr, _ = roc_curve(y_te, y_prob)
    ax.plot(fpr, tpr, color='#9467bd', lw=2, label=f"AUC = {roc_auc_score(y_te, y_prob):.4f}")
    ax.plot([0, 1], [0, 1], 'k--', lw=1)
    ax.legend(loc='lower right')
    roc_b64 = fig_to_base64(fig_r)

    return {
        'model': bag, 'y_prob': y_prob, 'metrics': metrics,
        'plots': {'bag_imp': imp_b64, 'roc_bag': roc_b64}
    }
